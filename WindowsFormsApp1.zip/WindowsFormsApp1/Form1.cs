﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Color.White);

            Pen myPen1 = new Pen(Brushes.Black, 3);
            
            HatchBrush myHatchBrush = new HatchBrush(HatchStyle.BackwardDiagonal, Color.Black, Color.White);// Кисть для штриховки

            //Штриховка правой части
            GraphicsPath path = new GraphicsPath();
            path.AddBezier(500,70,560,70,565,73,563,50);
            path.AddLine(563, 50, 603, 50);
            path.AddLine(603, 50, 603, 390);
            path.AddLine(603, 390, 453, 390);
            path.AddLine(453, 390, 453, 320);
            path.AddLine(453, 320, 563, 320);
            path.AddLine(563, 320, 563, 180);
            path.AddLine(563, 180, 500, 180);
            path.AddLine(500, 180, 500, 70);
            g.DrawPath(new Pen(Brushes.White, 3), path);
            g.FillPath(myHatchBrush, path);
            //---------------------------------------------------------

            // Обводка для правой части
            g.DrawBezier(myPen1, 500, 70, 560, 70, 565, 73, 563, 50);// Верхний правый сплайн
            g.DrawLine(myPen1, 563, 50, 603, 50);
            g.DrawLine(myPen1, 603, 50, 603, 390);
            g.DrawLine(myPen1, 603, 390, 453, 390);
            g.DrawLine(myPen1, 453, 320, 555, 320);
            g.DrawLine(myPen1, 563, 310, 563, 180);
            g.DrawLine(myPen1, 563, 180, 500, 180);
            g.DrawLine(myPen1, 500, 180, 500, 70);
            //-----------------------------------------------------------------
            
            //Штриховка слева
            GraphicsPath path1 = new GraphicsPath();
            path1.AddBezier(400,70,340,70,343,73,343,50);
            path1.AddLine(303, 50, 343, 50);
            path1.AddLine(303, 50, 303, 175);
            path1.AddBezier(387,180,369,180,339,180,303,175);
            path1.AddLine(387, 180, 400, 180);
            path1.AddLine(400, 180, 400, 70);
            g.DrawPath(new Pen(Brushes.White, 2), path1);
            g.FillPath(myHatchBrush, path1);
            //---------------------------------------------

            //Обводка левой части
            g.DrawBezier(new Pen(Brushes.Black,2), 387, 180, 369, 180, 339, 180, 303, 175);// Нижний сплайн
            g.DrawBezier(myPen1, 400, 70, 340, 70, 343, 73, 343, 50);//Верхний сплайн
            g.DrawLine(myPen1, 400, 180, 400, 70);
            g.DrawLine(myPen1, 387, 180, 400, 180);
            g.DrawLine(myPen1, 337, 314, 337, 180);
            g.DrawLine(myPen1, 453, 390, 303, 390);
            g.DrawLine(myPen1, 303, 50, 303, 390);
            g.DrawLine(myPen1, 303, 50, 343, 50);
            //----------------------------------------------------------------------

            g.DrawBezier(myPen1, 337,300,337,320,337,320,363,320);// Левый закруглённый угол
            g.DrawLine(myPen1,303, 320, 537, 320); //Горизонтальная линия через закруглённые углы
            g.DrawBezier(myPen1, 563,300,563,320,563,320,537,320);//Закруглённый левый угол
           

            //Скругление посередине
            g.DrawBezier(myPen1, 387,180,410,250,410,250,453,250);//Левая часть
           
            g.DrawBezier(myPen1, 513,180,490,250,490,250,453,250);//Правая часть
            //-------------------------------------------------------------

            // Левый белый прямоугольник
            g.FillRectangle(Brushes.White, 303, 85, 97, 80);
            g.DrawRectangle(myPen1, 303, 85, 97, 80);
            //--------------------------------------------------------------

            // Правый белый прямоугольник
            g.FillRectangle(Brushes.White, 500, 85, 103, 80);
            g.DrawRectangle(myPen1, 500, 85, 103, 80);
            //--------------------------------------------------------------

            // Пунктирная линия
            float[] dashValues = { 24, 2, 2, 2 };
            Pen dashPen = new Pen(Color.Black, 2);
            dashPen.DashPattern = dashValues;
            g.DrawLine(dashPen, 300, 125, 405, 125);
            g.DrawLine(dashPen, 497, 125, 608, 125);
            g.DrawLine(dashPen, 453, 395, 453, 245);
            
            //---------------------------------------------------------------

            // Штука слева + штриховка+ пунктирная линия
            GraphicsPath path2 = new GraphicsPath();
            path2.AddLine( 100, 175, 100, 295);
            path2.AddBezier(100, 175, 120, 175, 120, 175, 120, 195);
            path2.AddBezier(120, 195, 120, 215, 120, 215, 150, 215);
            path2.AddBezier(150, 215, 170, 215, 170, 215, 170, 235);
            path2.AddBezier(170, 235, 170, 255, 170, 255, 150, 255);
            path2.AddBezier(150, 255, 120, 255, 120, 255, 120, 275);
            path2.AddBezier(120, 275, 120, 295, 120, 295, 100, 295);
            g.DrawPath(new Pen(Brushes.Black, 2), path2);
            g.FillPath(myHatchBrush, path2);

            g.DrawLine(myPen1, 100, 175, 100, 295);
            g.DrawBezier(myPen1, 100, 175, 120, 175, 120, 175, 120, 195);
            g.DrawBezier(myPen1, 120, 195, 120, 215, 120, 215, 150, 215);
            g.DrawBezier(myPen1, 150, 215, 170, 215, 170, 215, 170, 235);
            g.DrawBezier(myPen1, 100, 295, 120, 295, 120, 295, 120, 275);
            g.DrawBezier(myPen1, 120, 275, 120, 255, 120, 255, 150, 255);
            g.DrawBezier(myPen1, 150, 255, 170, 255, 170, 255, 170, 235);

            g.DrawLine(dashPen, 420, 235, 100, 235);
            //------------------------------------------------------------

        }
    }
}
